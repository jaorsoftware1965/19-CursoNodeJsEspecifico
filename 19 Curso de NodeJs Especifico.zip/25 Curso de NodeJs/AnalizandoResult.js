// Declaro la variable que manejará el Módulo MySql
var mysql = require('mysql');

// Se Crea la Variable de Conexión
var conexion = mysql.createConnection({
  host: "localhost",
  user: "root",
  database:"dbscm",  // Indico la BD
  password: ""
});

// Intenta la conexion con la variable de conexion
conexion.connect(function(err) 
{
  // Valida que no haya habido error  
  if (err) 
     throw err;     
  else
  {

    // Prepara el Query para Insertar un Registro
    var sQuery = "INSERT INTO usuarios (nick, password, nombre, tipo) VALUES (?,?,?,?)";

    // Prepara los datos a insertar
    var nick="nick01", pass="pass01", nomb="nomb01", tipo="tipo01";

    // Ejecuta el Query de Inserción
    conexion.query(sQuery,[nick,pass,nomb,tipo], function (err, result) 
    {
       // Valida el Error 
       if (err) throw err;
       {
          // Mensaje de Inserción 
          console.log("Se ha insertado el Registro");
          //console.log(result);
          
          // Ciclo para analizar los valores
          for (var key in result)
          {
              // Verifica que no sea función
              if (key!="parse" && key!="write")
                 console.log(key+":"+result[key]);
              else
                 console.log(key+":Función")   
          }

          // Prepara el Query para actualizar
          sQuery = "UPDATE usuarios SET password=?, nombre=? WHERE nick=?";

          // Prepara los datos a insertar
          nick='nick01'
          pass="pass001";
          nomb="nomb001";

          // Ejecuta el Query de Inserción
          conexion.query(sQuery,[pass,nomb,nick], function (err, result) 
          {
             // Valida el Error 
             if (err) throw err;
             {
                // Mensaje de Inserción 
                console.log("Se ha actualizado el Registro");
                //console.log(result);
                
                // Ciclo para analizar los valores
                for (var key in result)
                {
                    // Verifica que no sea función
                    if (key!="parse" && key!="write")
                        console.log(key+":"+result[key]);
                    else
                        console.log(key+":Función")   
                }
              }
          });    
        }
    });        
  }
});