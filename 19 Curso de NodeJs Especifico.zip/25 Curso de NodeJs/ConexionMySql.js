// Declaro la variable que manejará el Módulo MySql
var mysql = require('mysql');

// Se Crea la Variable de Conexión
var conexion = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: ""
});

// Intenta la conexion con la variable de conexion
conexion.connect(function(err) 
{
  // Valida que no haya habido error  
  if (err) 
     throw err;
  else   
     // En caso de que no haya habido error, despliega mensaje   
     console.log("Conectado!");
});