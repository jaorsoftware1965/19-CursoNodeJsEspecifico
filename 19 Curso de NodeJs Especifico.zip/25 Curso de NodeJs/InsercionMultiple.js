// Declaro la variable que manejará el Módulo MySql
var mysql = require('mysql');

// Se Crea la Variable de Conexión
var conexion = mysql.createConnection({
  host: "localhost",
  user: "root",
  database:"dbscm",  // Indico la BD
  password: ""
});

// Función que ejecuta Consulta
function fnEjecutaConsulta(strMensaje)
{
    // Despliega el Mensaje
    console.log(strMensaje);

    // Query para consultar los Cocineros
    sQuery = "SELECT * FROM usuarios";
   
    // Ejecuta el Query
    conexion.query(sQuery,function (err, result,fields) 
    {  
       // Valida que no haya habido error
       if (err) 
          throw err;
       else
       {   
          // Despliega el Resultado   
          console.log("Despliegue de los Registros encontrados:"+result.length);
          console.log("---------------------------------------");
          
          // Ciclo para Imprimir uno por uno
          for (var indiceRows=0;indiceRows<result.length;indiceRows++)
          {
             // Despliega el Mensaje del Registro
             console.log("Registro:"+(indiceRows+1));
             for (var indiceFields=0;indiceFields<fields.length;indiceFields++)
             {                 
                 // Despliega el Dato desde el atributo y el row
                 console.log(fields[indiceFields].name+":"+result[indiceRows][fields[indiceFields].name]);       
             }
             // Linea divisoria
             console.log("---------------------------------------");                   
          }       
       }       
    });   
}

// Intenta la conexion con la variable de conexion
conexion.connect(function(err) 
{
  // Valida que no haya habido error  
  if (err) 
     throw err;     
  else
  {

    // Ejecuta la Consulta
    fnEjecutaConsulta("Consulta antes de Insertar");

    // Prepara el Query para Insertar un Registro
    var sQuery = "INSERT INTO usuarios (nick, password, nombre, tipo) VALUES ?";

    // Valores a insertar
    var values = 
    [
        ['nick01', 'pass01','nombre01','Extra'],
        ['nick02', 'pass02','nombre02','Extra'],
        ['nick03', 'pass03','nombre03','Extra']
    ];

    // Ejecuta el Query de Inserción
    conexion.query(sQuery,[values], function (err, result) 
    {
       // Valida el Error 
       if (err) throw err;
       {
          // Mensaje de Inserción 
          console.log("Se ha(n) insertado:"+result.affectedRows+ "Registro(s)");
          
          // Ejecuta Consulta
          fnEjecutaConsulta("Consulta despues de Insertar");          
        }
    });               
  }
});          
          
