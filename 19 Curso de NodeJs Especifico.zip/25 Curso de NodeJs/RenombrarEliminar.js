
// Carga el Módulo fs (File System)
var fs = require('fs');

// Mensaje
console.log("Intentando Renombrar Archivo ...");
// Utilizamos el método rename
fs.rename('test.php', 'test.bak', function (err) 
{
  // Valida que no haya habido error
  if (err) 
     throw err;  
  console.log('Archivo renombrado!');
});


// Mensaje
console.log("Intentando Eliminar Archivo ...");

// Utilizamos el método unlink
fs.unlink('archivorenombrado.dat',function (err) 
{
  // Valida que no haya habido error
  if (err) 
     throw err;
  console.log('Archivo eliminado!');
});
