
// Carga el Módulo Http en la variable correspondiente
var http = require('http');

// Carga el Módulo url
var url  = require("url");

// Crear el Servidor
http.createServer(function (request, response) 
{
   // Manda el HTTP header
   // HTTP Status: 200 : OK
   // Content Type: text/plain
   response.writeHead(200, {'Content-Type': 'text/plain'});
   
   // Manda al Documento Html la url; considerada la parte que viene 
   // Despues del nombre de Dominio
   response.write('Servidor ejecutandose en localhost:8080 ...\n\n');

   // Obtiene los parámetros GET que haya en la url
   var ParametrosGet = url.parse(request.url, true).query;
      
   // Despliega El Usuario y Password
   response.write("Usuario:"+ParametrosGet.user + "\nPassword:" + ParametrosGet.pass +"\n\n");

   // Despliega todos los parámetros que haya
   response.write("Lista de Parametros GET en la URL \n");
   response.write("--------------------------------- \n")
   for(var key in ParametrosGet) 
   {
       // Despliega cada uno de los parametros
       response.write('key: ' + key + '\n' + 'valor: ' + ParametrosGet[key]+"\n");
       
   }

   // Finaliza la Respueta del Cliente
   response.end(); 

}).listen(8080);

// Console will print the message
console.log('Servidor ejecutandose en localhost:8080 ...');

