// Declaro la variable que manejará el Módulo MySql
var mysql = require('mysql');

// Se Crea la Variable de Conexión
var conexion = mysql.createConnection({
  host: "localhost",
  user: "root",
  database:"dbscm",  // Indico la BD
  password: ""
});

// Intenta la conexion con la variable de conexion
conexion.connect(function(err) 
{
  // Valida que no haya habido error  
  if (err) 
     throw err;     
  else
  {
    // Prepara el Query
    var sQuery = "SELECT * FROM usuarios";

    // Variables para los Filtros
    var sTipo='barman';
    var sNick='sa';

    // Ejecutamos el Query
    //conexion.query(sQuery, function (err, result,fields) 
    //conexion.query("SELECT * FROM usuarios WHERE tipo='barman'", function (err, result,fields) 
    //conexion.query("SELECT * FROM usuarios WHERE tipo=?",[sTipo], function (err, result,fields) 
    conexion.query("SELECT * FROM usuarios WHERE tipo=? or nick=?",[sTipo,sNick], function (err, result,fields) 
    {  
       // Valida que no haya habido error
       if (err) 
          throw err;
       else
       {   
          // Despliega el Resultado   
          console.log("Se ha consultado la Tabla de Usuarios ");
          console.log("\n");
          console.log("Despliegue de los Registros encontrados:"+result.length);
          console.log("---------------------------------------");
          
          // Ciclo para Imprimir uno por uno
          for (var indiceRows=0;indiceRows<result.length;indiceRows++)
          {
             // Despliega el Mensaje del Registro
             console.log("Registro:"+(indiceRows+1));
             for (var indiceFields=0;indiceFields<fields.length;indiceFields++)
             {                 
                 // Despliega el Dato desde el atributo y el row
                 console.log(fields[indiceFields].name+":"+result[indiceRows][fields[indiceFields].name]);       
             }
             // Linea divisoria
             console.log("---------------------------------------");                   
          }
       }       
     });
  }
});