// Declaro la variable que manejará el Módulo MySql
var mysql = require('mysql');

// Se Crea la Variable de Conexión
var conexion = mysql.createConnection({
  host: "localhost",
  user: "root",
  database:"dbscm",
  password: ""
});

// Intenta la conexion con la variable de conexion
conexion.connect(function(err) 
{
  // Valida que no haya habido error  
  if (err) 
     throw err;     

    // Ejecuta un Query
    //conexion.query("USE dbscm", function (err, result) {
    conexion.query("SELECT * FROM usuarios", function (err, result,fields) {  
    if (err) 
       throw err;

    // Despliega el Resultado   
    console.log("Información de Fields:");
    console.log(fields);
    console.log("Número de Fields:"+fields.length);

    // Ciclo para cada uno de los Rows
    console.log("Desplegando cada row con su informacion ");
    for (var indice=0; indice < fields.length; indice++)
    {
      // Ciclo para Desplegar la información de las Columnas
      for (var Atributo in fields[indice])
      {
        // Verifica que no sea función
        if (Atributo!="parse" && Atributo!="write")
           // Despliega el Nombre del Atributo y su Valor
           console.log(Atributo+":"+fields[indice][Atributo]);
        else
           console.log(Atributo+":Funcion");
      }
      // Despliega una linea final
      console.log("-----------------------------");
    }        
  });
});