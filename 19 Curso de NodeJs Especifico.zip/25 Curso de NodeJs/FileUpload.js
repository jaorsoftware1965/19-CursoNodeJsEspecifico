
// Crea la var http para crear el Servidor
var http = require('http');

// Crea la variable para el módulo formidable
var formidable = require('formidable');

// Crea la variable para el manejo de archivos
var fs = require('fs');

// Crea el Servidor
http.createServer(function (request, response) 
{
  // Verifica si ha accedido al directorio para actualizar  
  if (request.url == '/fileupload') 
  {
    // Desplegando Mensaje de que se genera forma de Descargas
    console.log("Iniciando descarga ...");

    // Crea la variable para el manejo de información de formulario  
    var form = new formidable.IncomingForm();
    form.parse(request, function (err, fields, files) 
    {
      // Obtiene el path donde el archivo fue descargado        
      var oldpath = files.filetoupload.path;
      console.log("oldpath:"+oldpath);      
       
      // Crea el path donde se moverá el archivo
      var newpath = 'C:/Users/jaor/Documents/Curso NodeJs/' + files.filetoupload.name;
      console.log("newpath:"+newpath);      

      // Renombra el Archivo Descargado
      fs.rename(oldpath, newpath, function (err) 
      {
        // Valida si hubo error  
        if (err) 
           throw err;

        // Despliega el mensaje de que el archivo ha sido descargado y movido   
        response.write('Archivo Descargado y Movido !');
        
        // Finaliza la respuesta al cliente
        response.end();
      });
    });
  } 
  else 
  {
    // Desplegando Mensaje de que se genera forma de Descargas
    console.log("Forma para descarga desplegada ...");

    // Escribe al Cliente el Formulario de descarga
    response.writeHead(200, {'Content-Type': 'text/html'});
    response.write('<form action="fileupload" method="post" enctype="multipart/form-data">');
    response.write('<input type="file" name="filetoupload"><br>');
    response.write('<input type="submit">');
    response.write('</form>');
    
    // Finaliza la respuesta al Cliente
    return response.end();
  }
}).listen(8080); 

// Mensaje para indicar que se ha iniciado el Servidor
console.log("Servidor para Descargas iniciado ...");