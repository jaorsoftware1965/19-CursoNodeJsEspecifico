// Declaro la variable para mysql
var mysql = require('mysql');
 
// Creo la variable de conexion
var connection = mysql.createConnection(
    {
      host     : 'localhost',
      user     : 'root',
      password : '',
      database : 'dbscm'
    }
);

// Se intenta la conexión 
connection.connect(function(err) 
{
  if (err) 
  {
    console.error('error connecting: ' + err.stack);
    return;
  }
  else
     console.log('connected as id ' + connection.threadId);
});
 
/* Se inicia la transacción */
connection.beginTransaction(function(err) 
{
  // Verifica que haya error
  if (err) 
  { 
      // Lanza la execpción
      throw err; 
  }
  else
  {
    // Variable para el Query
    var sQuery = "INSERT INTO usuarios (nick,password,nombre,tipo)  VALUES (?,?,?,?)";

    // Ejecuta el Query de Inserción de un Usuario
    connection.query(sQuery, ["nick10","pass10","nomb10","tipo10"], function(err, result) 
    {
        // Mensaje
        console.log ("Insertando Usuario ...");

        // Verifica que haya habido error
        if (err) 
        { 
            // Roollback en caso de Error
            connection.rollback(function() 
            {
                // Lanza la excepción
               throw err;
            });
        }
     
        // Obtiene el Id para Insertar en Bitácora
        var usuario_id = result.insertId;
     
        // Prepara Query de Inserción a Bitácora
        sQuery ="INSERT INTO bitacora (usuario_id, descripcion) VALUES (?,?)";

        // Ejecuta el Query
        connection.query(sQuery, [usuario_id,'Registro del Usuario'],function(err, result) 
        {
           // Mensaje
           console.log ("Registrando en la Bitácora ...");

           // Verifica que haya habido Error 
           if (err) 
           { 
               // Ejecuta Rollback
               connection.rollback(function() 
               {
                  throw err;
               });
            }  
            
            // Confirma Transacción
            connection.commit(function(err) 
            {
               // Verifica que no haya habido Error 
               if (err) 
               { 
                   // Ejecuta Rollback
                   connection.rollback(function() 
                   {
                      throw err;
                   });
               }
               console.log('Transacción Completada.');
               
               // Finaliza la Conexión
               connection.end();
            });
        });
    });
  }  
});
