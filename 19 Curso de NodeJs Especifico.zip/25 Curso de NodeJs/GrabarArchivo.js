
// Carga el Módulo Http en la variable correspondiente
var http = require('http');

// Carga el Módulo url
var url  = require("url");

// Carga el Módulo fs (File System)
var fs = require('fs');

// Crear el Servidor
http.createServer(function (request, response) 
{
  
  // Obtiene los Tokens
  var urlTokens = url.parse(request.url, true);

  // Variable para el Nombre de un Archivo
  var filename = "." + urlTokens.pathname;

  // Manda el filename a la consola
  console.log("Desplegando:"+filename);

  // Lee el Archivo
  fs.readFile(filename, function(err, data) 
  {
      // Verifica si hay un Error
      if (err) 
      {
          // Despliega Mensajes de Error
          console.log("404 Archivo no encontrado:"+filename);
          response.writeHead(404, {'Content-Type': 'text/html'});
          return response.end("404 Not Found");
      }  
      else
      {
          // Desplegando
          console.log("Desplegando el Archivo:"+filename);
          response.writeHead(200, {'Content-Type': 'text/html'});
          response.write(data);

          // Grabando el Archivo
          console.log("Grabando el Archivo en:"+filename+"_copy");
          fs.writeFile(filename+"_copy", data, function (err) 
          {
             if (err) throw err;
                console.log('Saved!');
          }); 

          // Cierra la respuesta al Cliente
          return response.end();
      }      
  });   
}).listen(8080);

// Console will print the message
console.log('Servidor Web ejecutandose en localhost:8080 ...');