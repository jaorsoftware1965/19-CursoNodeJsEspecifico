// Cargamos la librería http
var http = require('http');

// Cargamos nuestra librería
var fechaHora = require('./FechaHora');

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write("La Fecha y la Hora es: " + fechaHora.fnFechaHora());
    res.end();
}).listen(8080); 

// Console will print the message
console.log('Servidor Ejecutándose en http://127.0.0.1:8080 \n');
console.log('La Fecha y Hora es:'+fechaHora.fnFechaHora());