
// Creamos la variable para los Eventos
var events = require('events');

// Creamos el objeto controlador de Eventos
var eventEmitter = new events.EventEmitter();

// Creamos el listener #1
var listner1 = function listner1() {
   console.log('listner1 ejecutado.');
}

// Creamos listener #2
var listner2 = function listner2() {
  console.log('listner2 ejecutado.');
}

// Creamos listener #3
var listner3 = function() {
  console.log('listner3 ejecutado.');
}

// Enlazamos el Evento Conexion con el Listener1
eventEmitter.addListener('conexion', listner1);

// Enlazamos el Evento Conexion con el Listener2
eventEmitter.on('conexion', listner2);

// Enlazamos el Evento Conexion con el Listener3
eventEmitter.on('conexion', listner3);

// Obtenemos el Número de Listener para el Evento Conexion
var eventListeners = require('events').EventEmitter.listenerCount
   (eventEmitter,'conexion');

// Lo Desplegamos   
console.log("Hay "+ eventListeners + " funcion(es) escuchando el evento conexion");

// Lanza el Evento; si no fuera así tendríamos que ejecutar cada función por Listener
console.log("Lanzamos el evento conexion ...");
eventEmitter.emit('conexion');

// Elimina un Listener para el Evento
eventEmitter.removeListener('conexion', listner1);

// Mensaje de que ya no está disponible
console.log("Listner1 ya no estará disponible desde ahora.");

// Lanzamos de nuevo el Evento
console.log("Lanzamos de nuevo el evento conexion ...");
eventEmitter.emit('conexion');

// Obtiene el número de Listeners
eventListeners = require('events').EventEmitter.listenerCount(eventEmitter,'conexion');
console.log("Hay "+eventListeners + " funcion(es) escuchando el evento conexion");

// Finaliza el Programa
console.log("Programa Terminado.");