
// Carga el Módulo Http en la variable correspondiente
var http = require('http');

// Carga el Módulo url
var url  = require("url");

// Crear el Servidor
http.createServer(function (request, response) 
{
   // Manda el http header
   response.writeHead(200, {'Content-Type': 'text/plain'});
   
   // Manda Mensaje de Servidor Ejecutándose
   response.write('Servidor ejecutandose en localhost:8080 ...\n\n');

   // Creamos la dirección completa
   var urlFull = "http://localhost:8080"+request.url;
      
   // Despliega  la Url Completa
   response.write("La Url Completa:"+urlFull+"\n\n");

   // Obtiene cada uno de los tokens
   var urlTokens = url.parse(urlFull, true);

   // Despliega todos los tokens
   response.write("Lista de Tokens en la URL \n");
   response.write("--------------------------------- \n")

   // Ciclo para los tokens
   for(var key in urlTokens) 
   {
       // Verifica si son funciones
       if (key!="query" && key!="parse" && key!="format" && 
           key!="resolve" && key!="resolveObject" && key!="parseHost")           
           // Despliega la llave indicando que es función
           response.write("Key:"+key+" Valor:"+urlTokens[key]+"\n");                 
       else   
           // Despliega la llave y el valor
           response.write("Key:"+key+" Funcion \n");       
   }
   // Deja una Linea
   response.write("\n");
   
   // Obtiene cada uno de los parámetros get
   var urlGets = urlTokens.query;

   // Despliega todos los parámetros que haya
   response.write("Lista de Parametros GET en la URL \n");
   response.write("--------------------------------- \n")

   // Ciclo para cada uno de los parámetros
   for(var key in urlGets) 
   {
       // Despliega cada uno de los parametros
       response.write('key: ' + key + '\n' + 'valor: ' + urlGets[key]+"\n");       
   }
  
   // Finaliza la Respueta del Cliente
   response.end(); 

}).listen(8080);

// Console will print the message
console.log('Servidor ejecutandose en localhost:8080 ...');