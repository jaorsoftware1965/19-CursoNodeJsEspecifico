
// Declaro la variable para manejar el mailer
var nodemailer = require('nodemailer');

// Genera la conexión al Servidor de Correo
var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    // Se indica el Usuario y Password
    user: 'jaorsoftware1965@gmail.com',
    pass: 'SoftwareInteligente'
  }
});

// OPciones para el Envío del Correo
var mailOptions = {
  from: 'jaorsoftware1965@gmail.com',
  to: 'jaorsoftware1965@hotmail.com',
  subject: 'Enviando Mensaje usando Node.js',
  text: 'Mensaje enviado Sencillamente'
};

// Acá en donde manda el Mail
transporter.sendMail(mailOptions, function(error, info)
{
  // Valida que haya habido Error
  if (error) 
  {
    // Despliega el Mensaje de Error  
    console.log(error);
  } 
  else 
  {
    // Mensaje de que se ha enviado el Correo
    console.log('El Mensaje se ha enviado: ' + info.response);
  }
});