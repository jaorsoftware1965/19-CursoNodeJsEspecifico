// Despliega un Mensaje en la Consola
console.log("Hola Mundo");