// Declaro la variable que manejará el Módulo MySql
var mysql = require('mysql');

// Se Crea la Variable de Conexión
var conexion = mysql.createConnection({
  host: "localhost",
  user: "root",
  database:"dbscm",  // Indico la BD
  password: ""
});

// Intenta la conexion con la variable de conexion
conexion.connect(function(err) 
{
  // Valida que no haya habido error  
  if (err) 
     throw err;     
  else
  {

    // Ejecuta un Query
    //conexion.query("USE dbscm", function (err, result) { // Pude activar la BD así
    conexion.query("SELECT * FROM usuarios", function (err, result,fields) 
    {  
       // Valida que no haya habido error
       if (err) 
          throw err;
       else
       {   
          // Despliega el Resultado   
          console.log("Se ha consultado la Tabla de Usuarios ");
          console.log(result);
          console.log("\n");
          console.log("Despliegue de los Registros encontrados:"+result.length);
          console.log("---------------------------------------");

          // Ciclo para Imprimir uno por uno
          for(var indice=0;indice<result.length;indice++)
          {
             // Despliega cada uno de los parametros
             console.log('Usuario  :' + result[indice].usuario_id);       
             console.log('Nick     :' + result[indice].nick);       
             console.log('Password :' + result[indice].password);       
             console.log('Nombre   :' + result[indice].nombre);       
             console.log('Tipo     :' + result[indice].tipo); 
             console.log("---------------------------------------");      
          }
       }       
     });
  }
});