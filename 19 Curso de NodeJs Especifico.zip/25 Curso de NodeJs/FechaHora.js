
// Crea la función para retornar la Fecha
exports.fnFechaHora = function () {
    // Retornamos la Fecha (JS)
    return Date();
}; 