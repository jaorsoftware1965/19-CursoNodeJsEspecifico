
// Carga el Módulo Http en la variable correspondiente
var http = require('http');

// Crear el Servidor
http.createServer(function (request, response) 
{
   // Manda el HTTP header
   // HTTP Status: 200 : OK
   // Content Type: text/plain
   response.writeHead(200, {'Content-Type': 'text/plain'});
   
   // Send the response body as "Hello World"
   response.end('Servidor Ejecutandose ...\n');
}).listen(8080);

// Console will print the message
console.log('Servidor Ejecutándose en http://127.0.0.1:8080');
